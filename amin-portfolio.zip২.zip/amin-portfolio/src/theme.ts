import {Easing, staticFile, delayRender, continueRender} from 'remotion';

export const FPS = 30;
export const W = 1920;
export const H = 1080;
export const DURATION = 25 * FPS; // রেফারেন্স ভিডিওর ২৫ সেকেন্ড

export const C = {
  bg: '#050805',
  bgGlow: '#1c3a06',
  lime: '#b6ff1a',
  green: '#6fd400',
  deep: '#2f6b00',
  white: '#ffffff',
  text: '#101010',
  sub: '#d9e6c8',
  paper: '#f4f4f2',
  star: ['#b6ff1a', '#3fd8ff', '#4a6bff', '#d63cff', '#ff2a3d'],
};

export const F = {
  display: '"Robot Go", Impact, sans-serif',
  script: '"Geetanjali Academic", Georgia, serif',
};

export const ease = {
  out: Easing.bezier(0.16, 1, 0.3, 1),
  inOut: Easing.bezier(0.65, 0, 0.35, 1),
  in: Easing.bezier(0.7, 0, 0.84, 0),
};

export const SPRING = {
  pop: {damping: 14, stiffness: 160, mass: 0.7},
  soft: {damping: 22, stiffness: 120, mass: 1},
};

// ফন্ট লোড (অফলাইনে চলে, public/fonts থেকে)
export const loadFonts = () => {
  const h = delayRender('fonts');
  Promise.all([
    new FontFace('Robot Go', `url(${staticFile('fonts/Robot_Go.ttf')})`).load(),
    new FontFace('Geetanjali Academic', `url(${staticFile('fonts/Geetanjali_Academic_Italic.otf')})`, {style: 'italic'}).load(),
  ])
    .then((fs) => { fs.forEach((f) => document.fonts.add(f)); continueRender(h); })
    .catch((e) => { console.error(e); continueRender(h); });
};

// ফ্রেম টাইমিং (সেকেন্ড থেকে ফ্রেম)
export const sec = (s: number) => Math.round(s * FPS);

// ইউজারের কনটেন্ট (রেফারেন্সের মতোই; শুধু নাম বদলানো)
export const CONTENT = {
  name: 'Amin Hasan',
  role1: 'Video editor',
  role2: 'Visual Storyteller',
  summaryTitle: 'Professional Summary',
  summary:
    'I Love Technology and AI related Fields, and I am a Video Editor and Motion Graphic designer with 5+ years of experience. I use AI to make my work faster. I have done high performing video content for brands and creators.',
  skills: ['Motion graphics', 'AI Visual Story', 'SaaS Animations', 'Youtube Videos', 'Branding'],
  short: 'Short-form Content edit',
  long: 'Long-form Content edit',
};
