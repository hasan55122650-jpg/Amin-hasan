import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {Hero} from './scenes/Hero';
import {ArcTransition, LongForm, ShortForm} from './scenes/Sections';
import {sec} from './theme';

// SFX চালু/বন্ধ ফ্ল্যাগ
const SFX_ON = true;

// ইভেন্ট অনুযায়ী SFX (ভিজ্যুয়ালের ২-৩ ফ্রেম আগে)
const SFX: {file: string; at: number; vol: number}[] = [
  {file: 'thud', at: 0, vol: 0.28},
  {file: 'whoosh', at: sec(2.2) - 3, vol: 0.25},
  {file: 'pop', at: sec(3) - 3, vol: 0.3},
  {file: 'chime', at: sec(4.6) - 3, vol: 0.25},
  {file: 'pop', at: sec(5) - 3, vol: 0.28},
  {file: 'click', at: sec(7.2) - 3, vol: 0.3},
  {file: 'click', at: sec(7.8) - 3, vol: 0.22},
  {file: 'whoosh', at: sec(11) - 3, vol: 0.3},
  {file: 'pop', at: sec(12.4) - 3, vol: 0.25},
  {file: 'whoosh', at: sec(16) - 3, vol: 0.28},
];

export const Main: React.FC = () => (
  <AbsoluteFill style={{background: '#050805'}}>
    <Sequence from={0} durationInFrames={sec(11.6)}><Hero /></Sequence>
    <Sequence from={sec(11)} durationInFrames={sec(1.2)}><ArcTransition /></Sequence>
    <Sequence from={sec(11.4)} durationInFrames={sec(4.6)}><ShortForm /></Sequence>
    <Sequence from={sec(16)} durationInFrames={sec(9)}><LongForm /></Sequence>
    {SFX_ON && SFX.map((s, i) => (
      <Sequence key={i} from={Math.max(0, s.at)}>
        <Audio src={staticFile(`sfx/${s.file}.wav`)} volume={s.vol} />
      </Sequence>
    ))}
  </AbsoluteFill>
);
