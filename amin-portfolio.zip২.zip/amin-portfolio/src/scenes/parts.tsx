import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig, random, OffthreadVideo, staticFile} from 'remotion';
import {C, F, SPRING, ease} from '../theme';

// ব্যাকগ্রাউন্ড: গ্লো মেশ + গ্রেইন + ভিনিয়েট
export const Backdrop: React.FC = () => {
  const f = useCurrentFrame();
  const drift = Math.sin(f / 45) * 40;
  return (
    <>
      <div style={{position: 'absolute', inset: 0, background: C.bg}} />
      <div style={{position: 'absolute', width: 1500, height: 1100, left: -200 + drift, top: -100,
        background: `radial-gradient(closest-side, ${C.bgGlow}, transparent)`, opacity: 0.9}} />
      <div style={{position: 'absolute', width: 1100, height: 900, right: -250 - drift, bottom: -250,
        background: `radial-gradient(closest-side, #0f3300, transparent)`, opacity: 0.8}} />
    </>
  );
};

export const GrainVignette: React.FC = () => (
  <>
    <svg style={{position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.09, mixBlendMode: 'overlay'}}>
      <filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="2" seed="3" /></filter>
      <rect width="100%" height="100%" filter="url(#n)" />
    </svg>
    <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.65) 100%)'}} />
  </>
);

// অক্ষর ধরে স্ট্যাগার (শুধু ইংরেজি "PORTFOLIO" এর জন্য)
export const StaggerLetters: React.FC<{text: string; start: number; size: number; gap?: number}> = ({text, start, size, gap = 4}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <div style={{display: 'flex', justifyContent: 'center', fontFamily: F.display, fontSize: size, lineHeight: 1, letterSpacing: 0}}>
      {text.split('').map((ch, i) => {
        const p = spring({frame: f - start - i * gap, fps, config: SPRING.pop});
        const glow = interpolate(f - start - i * gap, [0, 8, 24], [1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
        return (
          <span key={i} style={{
            display: 'inline-block',
            opacity: interpolate(p, [0, 1], [0, 1]),
            transform: `translateY(${interpolate(p, [0, 1], [60, 0])}px) scale(${interpolate(p, [0, 1], [0.85, 1])})`,
            background: `linear-gradient(180deg, ${C.lime} 10%, ${C.green} 60%, ${C.deep} 100%)`,
            WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent',
            filter: `drop-shadow(0 0 ${12 + glow * 30}px rgba(182,255,26,${0.25 + glow * 0.5}))`,
          }}>{ch}</span>
        );
      })}
    </div>
  );
};

// লাইন মাস্ক রিভিল
export const MaskReveal: React.FC<{start: number; children: React.ReactNode; style?: React.CSSProperties}> = ({start, children, style}) => {
  const f = useCurrentFrame();
  const t = interpolate(f - start, [0, 18], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: ease.out});
  return (
    <div style={{overflow: 'hidden', ...style}}>
      <div style={{transform: `translateY(${(1 - t) * 110}%)`, opacity: t}}>{children}</div>
    </div>
  );
};

// চার-কোণা তারা আইকন (SVG)
export const Star: React.FC<{color: string; size?: number}> = ({color, size = 34}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={{filter: `drop-shadow(0 0 8px ${color})`}}>
    <path d="M12 0 C13 8 16 11 24 12 C16 13 13 16 12 24 C11 16 8 13 0 12 C8 11 11 8 12 0Z" fill={color} />
  </svg>
);

// প্লেসহোল্ডার ক্লিপ কার্ড (নিজের ফুটেজ দিলে এখানে বসবে)
export const ClipCard: React.FC<{w: number; h: number; hue: number; label: string; start: number; i: number; src?: string}> = ({w, h, hue, label, start, i, src}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: f - start - i * 6, fps, config: SPRING.soft});
  const float = Math.sin((f + i * 20) / 38) * 6;
  return (
    <div style={{
      width: w, height: h, borderRadius: 26, position: 'relative', overflow: 'hidden',
      opacity: p, transform: `translateY(${(1 - p) * 90 + float}px) scale(${0.9 + p * 0.1})`,
      background: `linear-gradient(160deg, hsl(${hue} 55% 22%), hsl(${hue + 30} 60% 8%))`,
      boxShadow: '0 30px 60px rgba(0,0,0,0.25)',
    }}>
      <div style={{position: 'absolute', inset: 0, background: `radial-gradient(circle at 30% 20%, hsla(${hue},80%,55%,0.35), transparent 60%)`}} />
      {src ? (
        <OffthreadVideo src={staticFile(src)} muted style={{position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover'}} />
      ) : (
        <>
          <svg width="64" height="64" viewBox="0 0 64 64" style={{position: 'absolute', left: '50%', top: '46%', transform: 'translate(-50%,-50%)'}}>
            <circle cx="32" cy="32" r="30" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.5)" strokeWidth="2" />
            <path d="M26 20 L46 32 L26 44Z" fill="#fff" />
          </svg>
          <div style={{position: 'absolute', bottom: 22, width: '100%', textAlign: 'center', fontFamily: F.script, fontStyle: 'italic', color: 'rgba(255,255,255,0.8)', fontSize: 28}}>{label}</div>
        </>
      )}
    </div>
  );
};
export const _r = random;
