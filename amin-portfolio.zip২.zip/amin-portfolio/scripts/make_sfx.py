import numpy as np, wave
from scipy.signal import butter, lfilter
SR=44100
rng=np.random.default_rng(7)
def save(name,x,peak=0.8):
    x=x/ (np.max(np.abs(x))+1e-9)*peak
    w=wave.open(f'public/sfx/{name}.wav','wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((x*32767).astype('<i2').tobytes()); w.close()
def t(d): return np.linspace(0,d,int(SR*d),endpoint=False)
def lp(x,fc): b,a=butter(2,fc/(SR/2),'low'); return lfilter(b,a,x)
def hp(x,fc): b,a=butter(2,fc/(SR/2),'high'); return lfilter(b,a,x)
def bp(x,lo,hi): b,a=butter(2,[lo/(SR/2),hi/(SR/2)],'band'); return lfilter(b,a,x)
def env(x,a=0.005,d=8):
    n=len(x); e=np.exp(-np.linspace(0,d,n)); k=int(SR*a); e[:k]*=np.linspace(0,1,k); return x*e
def reverb(x): 
    y=x.copy()
    for dl,g in [(0.021,.25),(0.037,.15)]:
        s=int(SR*dl); y[s:]+=x[:-s]*g
    return y
tt=t(0.22); f=np.exp(-tt*18)*500+180
save('pop',reverb(lp(env(np.sin(2*np.pi*np.cumsum(f)/SR),0.003,9),4000)))
c=env(hp(rng.standard_normal(int(SR*0.08)),2500),0.001,7); save('click',reverb(lp(c,9000)))
d=0.7; tt=t(d); n=rng.standard_normal(len(tt)); sweep=np.zeros_like(n)
for i in range(0,len(n),2048):
    fc=400+2800*np.sin(np.pi*i/len(n)); seg=n[i:i+2048]; sweep[i:i+2048]=bp(seg,fc*0.6,fc*1.4) if len(seg)>50 else seg
fade=np.sin(np.pi*tt/d)**2; save('whoosh',reverb(lp(sweep*fade,6000)))
tt=t(0.5); ch=sum(np.sin(2*np.pi*f0*tt)*a for f0,a in [(880,1),(1320,.4),(1760,.2)]); save('chime',reverb(lp(env(ch,0.004,7),7000)))
tt=t(0.35); th=np.sin(2*np.pi*(60+90*np.exp(-tt*25))*tt); save('thud',lp(env(th,0.004,9),400),0.7)
